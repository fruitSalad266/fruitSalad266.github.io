!WARNING!

DO NOT CLICK ON SPAMBOT YET.

SAVE ALL OF YOUR FILES, NOW.

This spambot is designed to spam a link for fortnite v bucks 100+ times. To use, save all of your files first.
Get your IM service (hangouts, messenger, AIM, etc. etc.) and click on the box where you type in what you want to text. Now, double click the VBS file.
(After this, you may need to click on the box again)
(It will start in around a second) 
Wait and enjoy. (This may take upwards of 4 minutes- be warned!)

DISCLAIMER:
This is for PERSONAL USE ONLY. Any other usage can and may be illegal, and you are responsible for how you use this product, not the developers.
the developer is not responsible to any damage caused to your computer as a result of using this.

+----------------------------------------------------------------------+
| Get other great spambots/software packages @ fruitsalad266.github.io |
+----------------------------------------------------------------------+

r 8/26/18